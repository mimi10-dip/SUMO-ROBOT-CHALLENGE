#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

#include <Arduino.h>
#include "Config.h"
#include "Motor.h"
#include "LineSensor.h"

// =====================================================================
//                    STATE MACHINE - TRẠNG THÁI ROBOT
// =====================================================================
enum class RobotState {
  BORDER_STOP,   // Vừa phát hiện biên -> dừng khẩn cấp
  BORDER_BACK,   // Đang lùi lại
  BORDER_TURN,   // Đang xoay hướng thoát biên
  SWEEP,         // Xoay quét để đổi hướng
  CHARGE         // Lao thẳng để tối đa va chạm
};

extern RobotState currentState;
extern uint32_t stateEnterTime;
extern bool turnDirectionRight;

inline void changeState(RobotState newState) {
  currentState = newState;
  stateEnterTime = millis();
}

// =====================================================================
//                CHIẾN THUẬT "MÙ": QUÉT & LAO LUÂN PHIÊN
// =====================================================================
// Không có cảm biến phát hiện đối thủ, nên robot không thể biết đối
// thủ ở đâu. Thay vào đó, robot luân phiên giữa 2 hành vi:
//   1. SWEEP  : xoay tại chỗ 1 khoảng ngắn để đổi hướng nhắm tới.
//   2. CHARGE : lao thẳng hết tốc lực theo hướng vừa xoay tới, quét
//               qua 1 dải khu vực trên sàn — nếu đối thủ nằm trên
//               đường lao này, robot sẽ va chạm và đẩy được đối thủ.
// Lặp lại chu kỳ này liên tục, đổi hướng xoay luân phiên (trái/phải)
// sau mỗi vòng để dần dần quét được toàn bộ 360° quanh sàn đấu.
inline void sweepAndCharge() {
  if (currentState == RobotState::SWEEP) {
    if (turnDirectionRight) {
      turnRight(Config::SPEED_SWEEP);
    } else {
      turnLeft(Config::SPEED_SWEEP);
    }

    if (millis() - stateEnterTime >= Config::SWEEP_TIME_MS) {
      changeState(RobotState::CHARGE);
    }
  } else { // RobotState::CHARGE
    moveForward(Config::SPEED_CHARGE);

    if (millis() - stateEnterTime >= Config::CHARGE_TIME_MS) {
      // Hết 1 chu kỳ lao -> đổi hướng xoay cho vòng quét kế tiếp,
      // để không lặp lại đúng 1 đường thẳng mãi mãi.
      turnDirectionRight = !turnDirectionRight;
      changeState(RobotState::SWEEP);
    }
  }
}

// =====================================================================
//              XỬ LÝ 1 BƯỚC STATE MACHINE (gọi trong loop())
// =====================================================================
inline void updateStateMachine() {
  // --- Bước 1: Luôn kiểm tra biên trước tiên (ưu tiên tuyệt đối) ---
  bool borderDetected = detectBorder();
  bool isHandlingBorder = (currentState == RobotState::BORDER_STOP ||
                            currentState == RobotState::BORDER_BACK ||
                            currentState == RobotState::BORDER_TURN);

  if (borderDetected && !isHandlingBorder) {
    // Chỉ có 1 cảm biến nên không phân biệt được biên bên trái hay
    // phải -> đổi hướng xoay luân phiên mỗi lần gặp biên để tránh lặp
    // lại đúng 1 kiểu né (dễ bị kẹt góc nếu luôn né cùng 1 phía).
    turnDirectionRight = !turnDirectionRight;
    changeState(RobotState::BORDER_STOP);
  }

  // --- Bước 2: Chạy logic theo trạng thái hiện tại ---
  switch (currentState) {
    case RobotState::BORDER_STOP:
      stopMotor();
      if (millis() - stateEnterTime >= 50) {
        changeState(RobotState::BORDER_BACK);
      }
      break;

    case RobotState::BORDER_BACK:
      // Cả hai bánh lùi lại trong BORDER_BACK_TIME_MS (0.3s) khi gặp vạch trắng.
      moveBackward(Config::SPEED_ESCAPE);
      if (millis() - stateEnterTime >= Config::BORDER_BACK_TIME_MS) {
        changeState(RobotState::BORDER_TURN);
      }
      break;

    case RobotState::BORDER_TURN:
      if (turnDirectionRight) {
        turnRight(Config::SPEED_ESCAPE);
      } else {
        turnLeft(Config::SPEED_ESCAPE);
      }
      if (millis() - stateEnterTime >= Config::BORDER_TURN_TIME_MS) {
        changeState(RobotState::SWEEP);
      }
      break;

    case RobotState::SWEEP:
    case RobotState::CHARGE:
      sweepAndCharge();
      break;
  }
}

#endif // STATE_MACHINE_H
