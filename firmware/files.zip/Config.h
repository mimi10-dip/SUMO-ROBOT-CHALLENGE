#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// =====================================================================
//                        KHAI BÁO CHÂN (PINOUT)
// =====================================================================
namespace Pin {
  // Driver động cơ
  const uint8_t ENA = 5;
  const uint8_t ENB = 6;
  const uint8_t INA = 8;
  const uint8_t INB = 9;
  const uint8_t INC = 10;
  const uint8_t IND = 11;

  // Cảm biến dò line (chỉ 1 cái, gắn mép trước)
  const uint8_t LINE_SENSOR = 7;
}

// =====================================================================
//                    THAM SỐ CẤU HÌNH (dễ chỉnh sửa)
// =====================================================================
namespace Config {
  // --- Tốc độ động cơ (0-255) ---
  const uint8_t SPEED_CHARGE   = 255;  // Tốc độ khi lao thẳng (tấn công mù)
  const uint8_t SPEED_SWEEP    = 170;  // Tốc độ khi xoay quét
  const uint8_t SPEED_ESCAPE   = 220;  // Tốc độ khi lùi/né biên

  // --- Cảm biến dò line ---
  // Giá trị digitalRead() khi cảm biến gặp vạch TRẮNG.
  // Đã hiệu chỉnh theo test thực tế: trắng = LOW, đen = HIGH.
  const int LINE_WHITE_VALUE = LOW;

  // --- Thời gian xử lý né biên (ms) ---
  const uint32_t BORDER_BACK_TIME_MS = 300;  // Thời gian lùi khi gặp biên (0.3s)
  const uint32_t BORDER_TURN_TIME_MS = 350;  // Thời gian xoay sau khi lùi

  // --- Chu kỳ chiến thuật quét & lao (Sweep & Charge) ---
  // SWEEP: xoay tại chỗ để đổi hướng quét qua khu vực mới.
  // CHARGE: lao thẳng để tối đa khả năng va chạm đối thủ trên đường đi.
  const uint32_t SWEEP_TIME_MS  = 500;   // Thời gian xoay quét mỗi lần
  const uint32_t CHARGE_TIME_MS = 1400;  // Thời gian lao thẳng mỗi lần

  // --- Thời gian chờ khởi động theo luật thi đấu ---
  const uint32_t START_DELAY_MS = 5000;
}

#endif // CONFIG_H
