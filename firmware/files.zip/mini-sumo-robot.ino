/*
  =====================================================================
  MINI SUMO ROBOT - FIRMWARE (CHIẾN THUẬT "MÙ" - KHÔNG CẢM BIẾN ĐỐI THỦ)
  =====================================================================
  Vi điều khiển : Arduino Uno R3
  Driver        : Shield L298 (2 động cơ DC giảm tốc)
  Cảm biến      : 1x line hồng ngoại (dò biên) — KHÔNG dùng cảm biến
                  phát hiện đối thủ (siêu âm đã hỏng).
  Nguồn         : Pin Li-ion 2S (7.4V danh định, 8.4V đầy)

  CHIẾN THUẬT: Vì không có cảm biến phát hiện đối thủ, robot không thể
  "nhắm" vào đối thủ mà chỉ có thể tối đa hóa khả năng VA CHẠM bằng
  cách liên tục quét (xoay) rồi lao thẳng (tiến), lặp lại theo chu kỳ,
  đổi hướng luân phiên để quét khắp sàn đấu theo thời gian.

  KIẾN TRÚC: State Machine phi chặn (non-blocking), dùng millis() để
  quản lý thời gian, KHÔNG dùng delay() trong vòng lặp chính (chỉ dùng
  1 lần duy nhất lúc khởi động để chờ 5 giây theo luật thi đấu).

  Code được tách thành các module (xem các file .h cùng thư mục):
    - Config.h        : khai báo chân + tham số cấu hình
    - Motor.h          : điều khiển động cơ (tiến/lùi/xoay/dừng)
    - LineSensor.h      : đọc cảm biến dò line / phát hiện biên
    - StateMachine.h   : logic state machine + chiến thuật sweep & charge

  ĐẤU NỐI:
    --- Driver L298 ---
    ENA -> D5   (PWM tốc độ động cơ trái)
    ENB -> D6   (PWM tốc độ động cơ phải)
    INA -> D8   (chiều động cơ trái - chân 1)
    INB -> D9   (chiều động cơ trái - chân 2)
    INC -> D10  (chiều động cơ phải - chân 1)
    IND -> D11  (chiều động cơ phải - chân 2)

    --- Cảm biến dò line (1 cái, gắn mép trước) ---
    DO -> D7
  =====================================================================
*/

#include "Config.h"
#include "Motor.h"
#include "LineSensor.h"
#include "StateMachine.h"

// Biến trạng thái toàn cục (định nghĩa thật sự - khai báo extern trong StateMachine.h)
RobotState currentState = RobotState::SWEEP;
uint32_t stateEnterTime = 0;
bool turnDirectionRight = true;

void setup() {
  motorSetup();
  lineSensorSetup();
  stopMotor();

  Serial.begin(9600);
  Serial.println(F("[SUMO] Khoi dong. Cho 5 giay theo luat thi dau..."));

  // Đây là delay() DUY NHẤT được phép dùng, chỉ 1 lần lúc khởi động.
  delay(Config::START_DELAY_MS);

  Serial.println(F("[SUMO] Bat dau thi dau! (che do mu - khong co cam bien doi thu)"));
  changeState(RobotState::SWEEP);
}

void loop() {
  updateStateMachine();
}
