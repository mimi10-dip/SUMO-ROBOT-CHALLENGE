# Mini Sumo Robot – Firmware (Chiến thuật "Mù")

Firmware Arduino cho robot Mini Sumo, dùng chiến thuật **Sweep & Charge**
(quét rồi lao) do robot **không có cảm biến phát hiện đối thủ** (siêu âm
đã hỏng) — chỉ dùng 1 cảm biến dò line để né biên sàn đấu.

## Phần cứng

| Thành phần        | Chi tiết                                   |
|--------------------|---------------------------------------------|
| Vi điều khiển      | Arduino Uno R3                              |
| Driver động cơ     | Shield L298 (2 động cơ DC giảm tốc)         |
| Cảm biến           | 1x cảm biến dò line hồng ngoại (gắn mép trước) |
| Nguồn              | Pin Li-ion 2S (7.4V danh định, 8.4V đầy)    |

## Đấu nối chân

**Driver L298**

| Chân Arduino | Chức năng                     |
|--------------|--------------------------------|
| D5 (ENA)     | PWM tốc độ động cơ trái        |
| D6 (ENB)     | PWM tốc độ động cơ phải        |
| D8 (INA)     | Chiều động cơ trái – chân 1    |
| D9 (INB)     | Chiều động cơ trái – chân 2    |
| D10 (INC)    | Chiều động cơ phải – chân 1    |
| D11 (IND)    | Chiều động cơ phải – chân 2    |

**Cảm biến dò line**

| Chân Arduino | Chức năng    |
|--------------|--------------|
| D7           | DO (digital out) |

## Chiến thuật

Vì không có cảm biến phát hiện đối thủ, robot không thể "nhắm" đối thủ mà
tối đa hóa khả năng va chạm bằng cách lặp lại chu kỳ:

1. **SWEEP** (mặc định 0.5s) – xoay tại chỗ để đổi hướng nhắm.
2. **CHARGE** (mặc định 1.4s) – lao thẳng hết tốc lực theo hướng vừa xoay,
   quét qua một dải khu vực trên sàn.

Sau mỗi chu kỳ, hướng xoay được đổi luân phiên (trái/phải) để dần quét
được toàn bộ 360° quanh sàn đấu theo thời gian, thay vì lặp lại đúng một
đường thẳng.

Khi cảm biến dò line gặp vạch trắng (biên sàn):
1. Dừng khẩn cấp (~50ms).
2. Lùi cả hai bánh trong **0.3s**.
3. Xoay né trong 0.35s (hướng xoay đổi luân phiên mỗi lần gặp biên).
4. Quay lại chu kỳ Sweep & Charge.

Việc né biên luôn được ưu tiên tuyệt đối so với chiến thuật tấn công.

## Cấu trúc project

```
mini-sumo-robot/
├── mini-sumo-robot.ino   # setup() / loop() chính
├── Config.h              # Khai báo chân + tham số cấu hình
├── Motor.h                # Điều khiển động cơ (tiến/lùi/xoay/dừng)
├── LineSensor.h            # Đọc cảm biến dò line / phát hiện biên
├── StateMachine.h         # State machine + chiến thuật sweep & charge
└── README.md
```

## Tham số có thể tinh chỉnh

Tất cả nằm trong `Config.h`:

| Tham số                | Mặc định | Ý nghĩa                                      |
|--------------------------|----------|-----------------------------------------------|
| `SPEED_CHARGE`            | 255      | Tốc độ khi lao thẳng                          |
| `SPEED_SWEEP`             | 170      | Tốc độ khi xoay quét                          |
| `SPEED_ESCAPE`            | 220      | Tốc độ khi lùi/né biên                        |
| `BORDER_BACK_TIME_MS`     | 300      | Thời gian lùi khi gặp biên (0.3s)             |
| `BORDER_TURN_TIME_MS`     | 350      | Thời gian xoay sau khi lùi                    |
| `SWEEP_TIME_MS`           | 500      | Thời gian xoay quét mỗi lần                   |
| `CHARGE_TIME_MS`          | 1400     | Thời gian lao thẳng mỗi lần                   |
| `START_DELAY_MS`          | 5000     | Thời gian chờ khởi động theo luật thi đấu     |

## Nạp code

Mở `mini-sumo-robot.ino` bằng Arduino IDE (các file `.h` trong cùng thư
mục sẽ tự động hiện thành các tab khác nhau), chọn board **Arduino Uno**,
và nạp như bình thường.

## Lưu ý an toàn thi đấu

- `delay()` chỉ được dùng đúng 1 lần lúc khởi động (chờ 5 giây theo luật).
- Toàn bộ logic vòng lặp chính dùng `millis()` phi chặn (non-blocking).
- Né biên luôn được kiểm tra và xử lý ưu tiên tuyệt đối trong `loop()`.
