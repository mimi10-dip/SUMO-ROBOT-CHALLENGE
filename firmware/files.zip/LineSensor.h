#ifndef LINE_SENSOR_H
#define LINE_SENSOR_H

#include <Arduino.h>
#include "Config.h"

// =====================================================================
//                    DÒ BIÊN (LINE SENSOR)
// =====================================================================

inline void lineSensorSetup() {
  pinMode(Pin::LINE_SENSOR, INPUT);
}

// Trả về true nếu cảm biến gặp vạch trắng (biên sàn đấu).
inline bool detectBorder() {
  return (digitalRead(Pin::LINE_SENSOR) == Config::LINE_WHITE_VALUE);
}

#endif // LINE_SENSOR_H
