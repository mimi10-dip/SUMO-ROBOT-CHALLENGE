#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>
#include "Config.h"

// =====================================================================
//                    ĐIỀU KHIỂN ĐỘNG CƠ (MOTOR CONTROL)
// =====================================================================
// Lưu ý: chiều HIGH/LOW dưới đây đã được hiệu chỉnh theo test thực tế
// trên robot (moveForward() đi đúng chiều tiến thật). Nếu đấu lại dây
// động cơ khác, cần test lại và đảo chiều tương ứng.

inline void motorSetup() {
  pinMode(Pin::ENA, OUTPUT);
  pinMode(Pin::ENB, OUTPUT);
  pinMode(Pin::INA, OUTPUT);
  pinMode(Pin::INB, OUTPUT);
  pinMode(Pin::INC, OUTPUT);
  pinMode(Pin::IND, OUTPUT);
}

inline void moveForward(uint8_t speed) {
  digitalWrite(Pin::INA, LOW);
  digitalWrite(Pin::INB, HIGH);
  digitalWrite(Pin::INC, LOW);
  digitalWrite(Pin::IND, HIGH);
  analogWrite(Pin::ENA, speed);
  analogWrite(Pin::ENB, speed);
}

inline void moveBackward(uint8_t speed) {
  digitalWrite(Pin::INA, HIGH);
  digitalWrite(Pin::INB, LOW);
  digitalWrite(Pin::INC, HIGH);
  digitalWrite(Pin::IND, LOW);
  analogWrite(Pin::ENA, speed);
  analogWrite(Pin::ENB, speed);
}

// Xoay tại chỗ sang trái: bánh trái lùi, bánh phải tiến
inline void turnLeft(uint8_t speed) {
  digitalWrite(Pin::INA, HIGH);
  digitalWrite(Pin::INB, LOW);
  digitalWrite(Pin::INC, LOW);
  digitalWrite(Pin::IND, HIGH);
  analogWrite(Pin::ENA, speed);
  analogWrite(Pin::ENB, speed);
}

// Xoay tại chỗ sang phải: bánh trái tiến, bánh phải lùi
inline void turnRight(uint8_t speed) {
  digitalWrite(Pin::INA, LOW);
  digitalWrite(Pin::INB, HIGH);
  digitalWrite(Pin::INC, HIGH);
  digitalWrite(Pin::IND, LOW);
  analogWrite(Pin::ENA, speed);
  analogWrite(Pin::ENB, speed);
}

inline void stopMotor() {
  digitalWrite(Pin::INA, LOW);
  digitalWrite(Pin::INB, LOW);
  digitalWrite(Pin::INC, LOW);
  digitalWrite(Pin::IND, LOW);
  analogWrite(Pin::ENA, 0);
  analogWrite(Pin::ENB, 0);
}

#endif // MOTOR_H
